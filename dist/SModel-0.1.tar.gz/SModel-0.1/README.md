# smodel
 Statistical p-model extreme generator
